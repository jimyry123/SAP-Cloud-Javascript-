/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"ZSLM/SAPTRANSPORTS/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"ZSLM/SAPTRANSPORTS/test/integration/pages/LandingPage",
	"ZSLM/SAPTRANSPORTS/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "ZSLM.SAPTRANSPORTS.view.",
		autoWait: true
	});
});
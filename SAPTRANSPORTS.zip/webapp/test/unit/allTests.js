sap.ui.define([
	"ZSLM/SAPTRANSPORTS/test/unit/controller/LandingPage.controller"
], function () {
	"use strict";
});